// enum to define the InfoType of the AIInfoView

public enum InfoType{
    
    case RecipeInfo
    
    case TvInfo
    
    case EmailInfo
    
    case BlindsInfo
    
    case Credits
    
    case GoalOfApp
    
    case VoiceAssistentInfo
    
    
}
