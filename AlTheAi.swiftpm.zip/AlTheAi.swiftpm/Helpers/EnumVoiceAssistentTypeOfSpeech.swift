// enum to define the type of speech of the voice assistent in the PhoneView

public enum VoiceAssistentTypeOfSpeech
{
    
    case HelloSpeech
    
    case CallRestaurantSpeech
    
    case BookTableSpeech
    
}
