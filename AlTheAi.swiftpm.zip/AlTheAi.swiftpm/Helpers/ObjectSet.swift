import SceneKit

public class ObjectSet
{
    
    var objectNode: SCNNode
    
    public init(objectNode: SCNNode, position: SCNVector3) {
        self.objectNode = objectNode
        self.objectNode.position = position
    }
    
    
    
}
