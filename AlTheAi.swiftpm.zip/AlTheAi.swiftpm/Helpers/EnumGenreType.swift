// Enum to define type of genre of TvView

public enum GenreType
{
    
    case ActionGenre
    
    case ComedyGenre
    
    case RomanceGenre
    
    case FamilyFriendlyGenre
    
}

