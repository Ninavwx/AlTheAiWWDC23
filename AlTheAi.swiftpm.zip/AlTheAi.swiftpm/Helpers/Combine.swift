import Combine

let changeSceneEvent = PassthroughSubject<ActiveView, Never>()

let dismissIntroEvent = PassthroughSubject<Void, Never>()

let showMenuEvent = PassthroughSubject<Void, Never>()

let showInfoEvent = PassthroughSubject<Void, Never>()

let menuCreditsEvent = PassthroughSubject<Void, Never>()

let menuGoalOfTheAppEvent = PassthroughSubject<Void, Never>()

let fridgeShowRecipeEvent = PassthroughSubject<Void, Never>()

let tvStartQuizEvent = PassthroughSubject<Void, Never>()

let tvShowGenreEvent = PassthroughSubject<Int, Never>()

let tvFinishQuizEvent = PassthroughSubject<GenreType, Never>()

let userWritingEmailEvent = PassthroughSubject<Void, Never>()

let alWritingEmailEvent = PassthroughSubject<Void, Never>()

let blindsExplanationEvent = PassthroughSubject<Void, Never>()

let phoneShowVoiceAssistentEvent = PassthroughSubject<Void, Never>()

let phoneVoiceAssitenceTalkEvent = PassthroughSubject<VoiceAssistentTypeOfSpeech, Never>()

