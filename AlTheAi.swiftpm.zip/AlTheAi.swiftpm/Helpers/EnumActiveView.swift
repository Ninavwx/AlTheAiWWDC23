// enum to define active views

public enum ActiveView{
    
    case HouseView
    
    case AlIntroView
    
    case FridgeView
    
    case TvView
    
    case ComputerView
    
    case BlindsView
    
    case PhoneView
    
}
