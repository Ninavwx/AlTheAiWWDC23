import Foundation
import UIKit
import SceneKit

// File containing constants needed for the plauground

struct Constants
{
    
    struct Fonts
    {
       static let robotFont = "Menlo"
        
        static let robotFontSmall: CGFloat = 20
        
        static let robotFontMiddle: CGFloat = 30
        
        static let robotFontBig: CGFloat = 40
    }
    
    // constants for the accessibility label text
    struct AccessibilityLabelsText
    {
        static let buttonQuitLabel = "Button to quit"
        
        static let buttonBackHome = "Button back to home"
        
        static let buttonStartAlTv = "Click anywhere in the screen to test the Al tv streaming service"
        
    }
    
    // constants for the 3d models
    struct ObjIds
    {
       
        struct HouseView
        {
            static let fridgeId = "fridgeId"
            
            static let appleTvId = "appleTvId"
            
            static let blindsId = "blindsId"
            
            static let iphoneId = "iphoneId"
            
            static let computerId = "macId"
            
            static let tvId = "tvId"
            
            static let mainCameraId = "mainCameraId"
            
            static let fridgeCameraId = "FridgeCameraId"
            
            static let tvCameraId = "tvCameraId"
            
            static let macCameraId = "macCameraId"
        }
        
        struct FridgeView
        {
            
            static let idkWhatToCookTextId = "idkWhatToCookTextId"
            
            static let iNeedShoppingListId = "iNeedShoppingListTextId"
            
            static let helpTodayTextId = "helpTodayTextId"
            
        }
            
    }
    
    struct Scenes
    {
        
        static let houseScene = "houseScene.scn"
        
        static let fridgeScene = "fridgeChoiceScene.scn"
        
    }
    
    struct Texts
    {
        struct General
        {
            
            static let thankYouText = "Thank You!"
            
            static let howCanAlDoThis = "How can Al do this?"
            
            static let letsstartText = "Let's start!"
            
            static let okayText = "Okay"
            
            
        }
        
        struct AlIntro
        {
            
            static let introText = "Al: Hey there! I'm Al, your Artificial Inteligence - or AI - assistant.\nI am here to show you can use AI in your day to make tasks easier and more efficient.\nSimply touch an item (touchable items have arrows pointing to it) and I will help you with it."
            
            static let buttonIntro = "Let's start!"
            
        }
        
    
        
        struct FridgeView
        {
            static let whatDoYouNeedHelpWithText = "How can I help you today?"
            
            static let iDontKnowCookText = "I don't know what to cook..."
            
            static let makeShoppingListText = "I need to make a shopping list"
            
            static let recipeText = "Human: I don't know what to cook...\n\nAl: With the ingredients in your fridge, you can make a Creamy Tomato Pasta recipe:\n\n1. Dice the tomatoes and add it to a pan. Let it simmer until they break down.\n\n2. Pour in the milk and stir until well combined. Let it simmer until the sauce thickens slightly.\n\n3. Add the cooked pasta to the pan and toss until it is coated with the sauce.\n\n4. Enjoy your creamy tomato pasta!\n"

            
        }
        
        struct TvView
        {
            
            static let someQuestionsText = "I will ask you some questions now in order to recommend the best option of series for you"
            
        
            
            static let whatIsAge = "How old are you?"
            
            static let whatGenre = "What genre do you like the best?"
            
            static let genreComedy = "Comedy"
            
            static let genreRomance = "Romance"
            
            static let genreAction = "Action"
            
            static let genreSuspense = "Suspense"
            
            static let genreFamilyFriendly = "Family friendly"
            
            static let alRecommends = "Al recommends:"
            
        }
        
        struct ComputerView
        {
            
            static let sendEmailToFriendText = "Al, send an email to my friend"
            
            static let pleaseWriteEmailToText = "Hey Al, please write an email to "
            
            static let invitingHimTo = "inviting him/her/them to "
            
            
        }
        
        struct BlindsView
        {
            
            static let explanationSunSliderText = "Use the slider to change the position of the sun and I will move the blinds accordingly, maximizing the amount of light in your home while minimizing heat"
            
        }
        
        struct Info
        {
            
            static let menuCreditsText = "'Al the AI' was developed by Nina Gitelman."
            
            static let menuGoalOfTheAppText = "With Artificial Intelligence becoming more popular and accessible to the public, there have been a lot of discussions on whether it is a good thing, how we can use it, and how it will affect us. My goal with “Al the AI” is to show people how we can, and already do, use Artificial Intelligence in our day-by-day.\n\n With the examples in the app, I hope to show people that Artificial Intelligence can bring a lot of good things, such as giving you ideas (generating recipes), writing a text from a request (writing an email), making simple calls for you (calling a restaurant), personalizing platforms and recommending products (recommending series in a streaming service) and automatizing tasks smartly (moving blinds according to the sun)"
            
            static let recipeAiInfoText = "How can Al give you a recipe based on the ingredients in your fridge?\n\nAn AI can read the ingredients in your fridge and suggest recipes based on those ingredients.\n\nThis is possible through a process known as Natural Language Processing (NLP) and Machine Learning (ML).\n\nFirst, the AI understands the natural language text input, which in this case is the list of ingredients.\n\nThis is done through Natural Language Processing techniques such as tokenization, part-of-speech tagging, and dependency parsing, which help the AI to extract the relevant information from the text.\n\nNext, the AI uses Machine Learning algorithms to analyze the extracted data and make predictions about which recipes would best match the available ingredients.\nThe AI can use a variety of techniques, such as clustering or decision trees, in order to identify the most suitable recipe option.\n\nFinally, the AI presents the recommended recipe to the user in a user-friendly format, such as step-by-step instructions."
                
            static let tvInfo = "Streaming services use Artificial Intelligence to recommend TV shows and movies to users.\n\nThe Artificial Intelligence analyzes their viewing history, search history, and other data points such as user demographics, ratings, reviews, and preferences to make the recommendation. It uses collaborative filtering, content-based filtering, or a hybrid of both, to identify patterns in user behavior and recommend TV shows and movies that match their preferences.\n\nThis helps streaming services provide more accurate and personalized recommendations to users.\n\n“Al tv” shows this in a very simplified manner, by setting your age and saying your preferred genre, you receive the title of a series recommended based on this data."
            
            static let emailInfo = "As seen, Artificial Intelligence can take a proposal of text, in this example an email, and output the desired text in the desired format.\n\nThis type of AI is known as natural language generation - or NLG. NLG is a branch of artificial intelligence that uses machine learning algorithms to automatically generate human-like language from data or structured information.\n\nIn the case of writing an email to a friend, the AI system first needs to be trained in a large amount of formal and informal emails. Thus, it learns the typical structure, tone, and language used in such texts. It is also programmed with specific rules and guidelines for writing an email, such as using appropriate salutations and addressing the recipient correctly.\n\nOnce trained and programmed, the AI system can take an input prompt, such as “write a formal email to a friend inviting him to an event at a specific time” and use its knowledge and rules to generate a complete and coherent email.\n\nThe AI system uses natural language processing - or NLP - techniques to understand the meaning and context of the input prompt in order to generate a response that meets the desired criteria.\n\nOverall, NLG technology has come a long way in recent years, and it is becoming increasingly common in a variety of applications, including content creation, customer service, and even journalism.\n\nHowever, it is important to note that even the most advanced NLG systems are still far from perfect and often require human oversight to ensure accuracy and coherence."
            
            
            static let blindsInfo = "An Artificial Intelligence - or AI - system can control the position of blinds to optimize sunlight and minimize excess heat.\n\nThe system integrates a sensor system that detects the position of the sun, the temperature of the room and the current position of the blinds.\n\nIt then uses this information to determine the optimal position for the blinds in order to maximize sunlight and minimize heat. This is done through the use of machine learning algorithms that analyze the data from the sensors and adjust the position of the blinds accordingly.\n\nFor example, if the temperature in the room is getting too hot and the sun is shining directly into the room, the AI adjusts the position of the blinds to block some of the sunlight, reducing the amount of heat entering the room. Conversely, if the temperature is too cold and the sun is not shining into the room, the AI system adjusts the blinds to allow more sunlight to enter, increasing the temperature.\n\nOverall, an AI system optimizes the position of blinds based on real-time data, allowing greater energy efficiency and comfort."
            
            static let voiceAssistent = "When you talk or text a voice assistant, you are using Artificial Intelligence.\n\nYour phone's voice assistant is an AI-powered machine that uses natural language processing (NLP) to understand and interpret your request. In this example a button was used to represent a spoken or written request\n\nThe first step in the process is to understand the request. The NLP algorithms analyze the text to understand the meaning of the request and identify key pieces of information, in this example, the name of the restaurant and the desired time for the reservation.\n\nOnce the voice assistant has identified the relevant information, it then uses machine learning algorithms and pre-programmed logic to perform the requested task. In this case, it would access a database of restaurants, find the phone number for your favorite restaurant, call the restaurant and book a table at the specified time.\n\nOverall, this process demonstrates how AI technologies like natural language processing, speech recognition, and machine learning can work together to enable voice assistants to understand and act upon spoken requests in a way that simulates human-like interaction."
            
        }
        
        struct PhoneView
        {
            
            static let titleAlVoiceAssistentText = "Al the Voice Assistent"
            
            static let turnOnSoundText = "* For a better experience, turn on the sound"
            
            static let callRestaruantBookTableButtonText = "Please call my favourite restaurant and book a table for today at 21"
            
            static let bookTodayAtTimeText = "Book for today at 7:30"
            
            struct Speeches
            {
                
                static let speechHello = "Hello, I am Al, how can I help you today?"
                
                static let speechCallingRestaurant = "Calling 123-4567... Hello, I would like to book a table for today at 7 pm... Oh, you only have for today at 7:30 pm?"
                
                static let speechBookTable = "Okay, so can I book it for today at 7:30 pm?...Great, thank you!"
                
            }
            
        }
        
        
    }
    
    struct Images
    {
        
        static let alImage = "alImage"
        
        
        struct TvView
        {
            
            static let tvBackground = "alTvBackground"
            
            static let tvButton = "alTvButton"
            
            static let seriesComedy = "seriesComedy"
            
            static let seriesRomance = "seriesRomance"
            
            static let seriesKids = "seriesKids"
            
            static let seriesAction = "seriesAction"
            
            
        }
        
        struct ComputerView
        {
            
            
            static let computerBackground = "computerScreen"
            
        }
        
        struct BlindsView
        {
            static let blindsOpen = "bgBlindsOpened"
            static let blindsClose = "bgBlindsClosed"
            static let houseBackground = "blindsBackground"
            
        }
    }
    
}
