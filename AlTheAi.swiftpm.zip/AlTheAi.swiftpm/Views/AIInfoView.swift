import SwiftUI


// View that shows the technical information on how Artificial Inteligence can do each of the scenes
// it addapts according to the current scene (type of information recieved in init)

struct AiInfoView: View
{
    
    @State var infoType: InfoType
    
    init(infoType: InfoType) {
        self.infoType = infoType
    }
    
    var body: some View
    {
        
        VStack(alignment: .center)
        {
            
            ScrollView
            {
                switch infoType {
                    
                    case .RecipeInfo:
                        
                        Text(Constants.Texts.Info.recipeAiInfoText)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                        
                        
                    case .TvInfo:
                        
                        Text(Constants.Texts.Info.tvInfo)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                    
                    case .EmailInfo:
                        Text(Constants.Texts.Info.emailInfo)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                    
                    
                    case .BlindsInfo:
                    Text(Constants.Texts.Info.blindsInfo)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                    
                    
                case .VoiceAssistentInfo:
                    Text(Constants.Texts.Info.voiceAssistent)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                    
                    case .Credits:
                    Text(Constants.Texts.Info.menuCreditsText)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                        
                    case .GoalOfApp:
                    Text(Constants.Texts.Info.menuGoalOfTheAppText)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .lineSpacing(15)
                            .padding(30)
                    
                    
                }
            }
            
            // button to quit
            Button( "X", action: { showInfoEvent.send() })
            .buttonStyle(.borderless)
            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontBig))
            .padding(20)
            .accessibilityLabel(Constants.AccessibilityLabelsText.buttonQuitLabel)
        }
        .background(Color(white: 1, opacity: 0.9))
        .cornerRadius(30)

        
    }
    
}

struct AiInfoView_Previews: PreviewProvider {
    
    
    static var previews: some View {
        
        AiInfoView(infoType: .GoalOfApp)
        
    }
}
