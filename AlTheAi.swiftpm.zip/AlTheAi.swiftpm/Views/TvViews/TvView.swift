//
//  SwiftUIView.swift
//  
//
//  Created by Marcelo Treistman on 06/04/23.
//

import SwiftUI

struct TvView: View
{
    
    
    
    @State var startQuiz = false
    
    @State var showAge = true
    @State var showGenre = false
    
    @State var age = 0
    
    @State var countRomance = 0
    @State var countFamilyFriendly = 0
    @State var countAction = 0
    @State var countComedy = 0
    
    @State var showInfo: Bool = false
    
    
    
    var body: some View
    {
        
            ZStack
            {
                // set the background color to black
                Color.black
                    .ignoresSafeArea()
                
                
                
                VStack(alignment: .center)
                {
                    
                    HStack(alignment: .center)
                    {
                        
                        
                        Image(Constants.Images.TvView.tvButton) // image of Al Tv
                            .resizable()
                            .scaledToFit()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 200)
                        
                        
                        
                    }
                    .padding(40)
                    
                    
                    if !startQuiz // if havent started the quiz: show explnation text and button to start
                    {
                        Text(Constants.Texts.TvView.someQuestionsText)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                            .multilineTextAlignment(.center)
                            .padding(50)
                            .foregroundColor(.white)
                            .lineSpacing(15)
                        
                        Button(Constants.Texts.General.letsstartText, action: {tvStartQuizEvent.send()})
                            .buttonStyle(.bordered)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                            .padding(50)
                    }
                    
                    else if showAge // if asking the age, show text to ask for age
                    {
                        
                        VStack(alignment: .center)
                        {
                            
                            Text(Constants.Texts.TvView.whatIsAge)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                .foregroundColor(.white)
                            
                            
                            // text to enter age
                            TextField(Constants.Texts.TvView.whatIsAge, value: $age, format: .number)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                .padding(100)
                                .multilineTextAlignment(.center)
                                .submitLabel(.next)
                                .foregroundColor(.white)
                                .onSubmit
                            {
                                
                                if age < 6 // if it is a kid, add one to the kids show
                                {
                                    countFamilyFriendly = countFamilyFriendly + 1
                                }
                                
                                showAge = false
                                showGenre = true
                                
                            }
                        }
                    }
                    
                    // ask what genre the user likes the most
                    else if showGenre
                    {
                        VStack
                        {
                            // text what genre you like the best
                            Text(Constants.Texts.TvView.whatGenre)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                .foregroundColor(.white)
                                .lineSpacing(15)
                            
                            HStack
                            {
                                
                                // button action
                                Button(Constants.Texts.TvView.genreAction, action: {tvFinishQuizEvent.send(.ActionGenre)})
                                    .buttonStyle(.bordered)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                
                                // button Comedy
                                Button(Constants.Texts.TvView.genreComedy, action: {tvFinishQuizEvent.send(.ComedyGenre)})
                                    .buttonStyle(.bordered)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                
                                // button action
                                Button(Constants.Texts.TvView.genreRomance, action: {tvFinishQuizEvent.send(.RomanceGenre)})
                                    .buttonStyle(.bordered)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                
                                // button action
                                Button(Constants.Texts.TvView.genreFamilyFriendly, action: {tvFinishQuizEvent.send(.FamilyFriendlyGenre)})
                                    .buttonStyle(.bordered)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                
                            }
                            
                            
                        }
                        
                    }
                    else //  if it got to the end (quiz started, not show and not age)
                    {
                        
                        VStack(alignment: .center)
                        {
                            Text(Constants.Texts.TvView.alRecommends)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                .padding(.top, 50)
                                .padding(.leading, 50)
                                .padding(.trailing, 50)
                                .foregroundColor(.white)
                            
                            // if comedy is recommended
                            if ((countComedy > countAction) && (countComedy > countRomance) && (countComedy > countFamilyFriendly))
                            {
                                
                                Image(Constants.Images.TvView.seriesComedy)
                                    .resizable()
                                    .cornerRadius(50)
                                    .padding(50)
                                    .aspectRatio(contentMode: .fill)
                                    .scaledToFit()
                                
                                
                            }
                            // if action is recommended
                            else if ((countAction > countComedy) && (countAction > countRomance) && (countAction > countFamilyFriendly))
                            {
                                
                                Image(Constants.Images.TvView.seriesAction)
                                    .resizable()
                                    .cornerRadius(50)
                                    .padding(50)
                                    .aspectRatio(contentMode: .fill)
                                    .scaledToFit()
                                
                            }
                            else if ((countRomance > countComedy) && (countRomance > countAction) && (countRomance > countFamilyFriendly))
                            {
                                
                                Image(Constants.Images.TvView.seriesRomance)
                                    .resizable()
                                    .cornerRadius(50)
                                    .padding(50)
                                    .aspectRatio(contentMode: .fill)
                                    .scaledToFit()
                                
                                
                            }
                            else if ((countFamilyFriendly >= countComedy) && (countFamilyFriendly >= countAction) && (countFamilyFriendly >= countRomance))
                            {
                                
                                Image(Constants.Images.TvView.seriesKids)
                                    .resizable()
                                    .cornerRadius(50)
                                    .padding(50)
                                    .aspectRatio(contentMode: .fill)
                                    .scaledToFit()
                                
                                
                            }
                            
                            HStack
                            {
                                
                                Button("X", action: {changeSceneEvent.send(.HouseView)})
                                    .accessibilityLabel(Constants.AccessibilityLabelsText.buttonQuitLabel)
                                    .buttonStyle(.borderless)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                    .padding(.trailing, 70)
                                
                                Button(Constants.Texts.General.howCanAlDoThis, action: {showInfoEvent.send()})
                                    .accessibilityLabel(Constants.AccessibilityLabelsText.buttonQuitLabel)
                                    .buttonStyle(.borderless)
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                                    .padding(.leading, 70)
                                
                                
                            }
                            .padding(30)
                            
                        }
                        
                    }
                    
                    
                    
                }
                .onReceive(tvStartQuizEvent) // event to start the quiz
                {
                    startQuiz = true
                    showAge = true
                }
                .onReceive(tvFinishQuizEvent) // event to calculate the score based on the currGenre and finish the quiz
                { currGenre in
                    
                    switch currGenre
                    {
                    case .ActionGenre:
                        countAction = countAction + 1
                        
                    case .FamilyFriendlyGenre:
                        countFamilyFriendly = countFamilyFriendly +  1
                        
                    case .RomanceGenre:
                        countRomance = countRomance + 1
                        
                    case .ComedyGenre:
                        countComedy = countComedy+1
                    }
                    
                    showGenre = false
                    
                }
                .onReceive(showInfoEvent) // event to show the AI info
                {
                    showInfo.toggle()
                }
                
            }
            
            
            if showInfo // if show the AI info, cal View to show the AI info for the this scene
            {
                AiInfoView(infoType: .TvInfo)
                
            }
        
    }
    
    
}

struct TvView_Previews: PreviewProvider {
    
    
    static var previews: some View {
        
        TvView()
    }
}
