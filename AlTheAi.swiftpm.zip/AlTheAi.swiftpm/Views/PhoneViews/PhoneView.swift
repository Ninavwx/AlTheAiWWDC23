import SwiftUI
import AVFoundation

struct PhoneView: View {
    
    @State var syn = AVSpeechSynthesizer()
    
    @State var currentSpeach: VoiceAssistentTypeOfSpeech = .HelloSpeech
    
    @State var currText: String = " "
    
    @State var finalText: String = " "
    
    @State var finishedTyping: Bool = false
    
    @State var showInfo: Bool = false
    
    
    
  var body: some View
    {
        
        ZStack
        {
            
            
            VStack()
            {
                HStack(alignment: .top) // images of battery and wifi to represent the top part of the phone
                {
                
                    Image(systemName: "battery.75")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30)
                        .padding(.trailing, 50)
                        .foregroundColor(.white)
                    
                    Image(systemName: "wifi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30)
                        .foregroundColor(.white)
                   
                    Spacer()
                }
                .padding(.top, 50)
                
                Spacer()
            }
            
            
            VStack()
            {
                Spacer()
                
                    
                    Text(Constants.Texts.PhoneView.titleAlVoiceAssistentText)
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                        .foregroundColor(.white)
                        .lineSpacing(15)
                        .padding(.bottom, 30)
                    
                    Text(currText)
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                        .foregroundColor(.white)
                        .lineSpacing(15)
                        .padding(.bottom, 30)
                        .onAppear()
                        {
                            phoneVoiceAssitenceTalkEvent.send(.HelloSpeech)
                        }

                    
                    if finishedTyping
                    {
                        switch currentSpeach
                        {
                            
                                
                            case .HelloSpeech:
                                
                                
                                Button(action: {phoneVoiceAssitenceTalkEvent.send(.CallRestaurantSpeech)})
                                {
                                    Text(Constants.Texts.PhoneView.callRestaruantBookTableButtonText)
                                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        .lineSpacing(15)
                                    
                                    
                                }
                                .buttonStyle(.bordered)
                                
                                
                            case .CallRestaurantSpeech:
                                
                                
                                Button(action: {phoneVoiceAssitenceTalkEvent.send(.BookTableSpeech)})
                                {
                                    Text(Constants.Texts.PhoneView.bookTodayAtTimeText)
                                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        .lineSpacing(15)
                                    
                                }
                                .buttonStyle(.bordered)
                                .padding(.top, 30)
                                
                            case .BookTableSpeech:
                               
                                HStack
                                {
                                    Spacer()
                                    Button(action: {changeSceneEvent.send(.HouseView)})
                                    {
                                        Text(Constants.Texts.General.thankYouText)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .lineSpacing(15)
                                        
                                    }
                                    .buttonStyle(.bordered)
                                    .padding(.top, 30)
                                    
                                    Spacer()
                                    
                                    Button(action: {showInfoEvent.send()})
                                    {
                                        Text(Constants.Texts.General.howCanAlDoThis)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .lineSpacing(15)
                                        
                                    }
                                    .buttonStyle(.bordered)
                                    .padding(.top, 30)
                                    
                                    Spacer()
                                }
                        }
                        
                    
                }
                Spacer()
                
            }
            .padding(30)
            
            if showInfo // if show the info, show AI info about this biew
            {
                AiInfoView(infoType: .VoiceAssistentInfo)
                
            }
            
            
        }
        .background((Color.black).ignoresSafeArea())
        .onReceive(phoneVoiceAssitenceTalkEvent) // depending on the recieved speech, say something different
        { typeSpeach in
            
            
            currentSpeach = typeSpeach
            
            let text: String
            
            switch typeSpeach // check the type of speech and set the text accordingly
            {
                
                
            case .HelloSpeech:
                text = Constants.Texts.PhoneView.Speeches.speechHello
                
            case .CallRestaurantSpeech:
                
                text = Constants.Texts.PhoneView.Speeches.speechCallingRestaurant
                
                
                
            case .BookTableSpeech:
                
                text = Constants.Texts.PhoneView.Speeches.speechBookTable
                
            }
            
            // set the text to be typed as the text we defined based on the type of speech and call the function to make the typewriter effect
            finalText = text
            typewriter()
            
            // speack the defined text
            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
            syn.speak(utterance)
           
        }
        .onReceive(showInfoEvent)
        {
            showInfo.toggle()
        }
        
    }
    
    
    // function to make the typewriter effect
    func typewriter(at position: Int = 0)
    {
        
        if position == 0
        {
                currText = ""
        }
        if position < finalText.count
        {
            finishedTyping = false
            
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1)
                {
                    currText.append(finalText[position])
                    typewriter(at: position + 1)
                }
            
        }
        else
        {
            finishedTyping = true
            
        }
        
    }
    
    
}

struct PhoneView_Previews: PreviewProvider
{
    static var previews: some View
    {
        PhoneView()
    }
}
