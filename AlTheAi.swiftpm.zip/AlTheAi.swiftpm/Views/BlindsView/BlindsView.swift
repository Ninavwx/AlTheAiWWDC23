

import SwiftUI

struct BlindsView: View
{
    @State var showExplanation: Bool = true
    
    @State var showInfo: Bool = false
    
    @State var sunPositionX: CGFloat = 0
    
    @State var isEditing: Bool = false
    @State var blindsHeight: CGFloat = 3
    
    @State var blindsImageName: UIImage = UIImage(named: Constants.Images.BlindsView.blindsOpen)!
    
    
    var body: some View
    {
        ZStack
        {
            
            VStack
            {
                
                
                
                VStack(alignment: .trailing)
                {
                    
                    // image of the sun (moved according to the slider)
                    
                    Image(systemName: "sun.max")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .position(x: sunPositionX+30)
                        .foregroundColor(.yellow)
                        .padding(.top, 50)
                    
                }
                    
                
                if showExplanation // if supposed to show the explanation of how to use the slider
                {
                    HStack()
                    {
                        
                        // image of al
                        Image(Constants.Images.alImage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                            .padding(.trailing, 10)
                        
                        // exaplanation
                        Text(Constants.Texts.BlindsView.explanationSunSliderText)
                            .lineSpacing(15)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .padding(10)
                        
                        // button to close explanation
                        Button(action: {blindsExplanationEvent.send()})
                        {
                            Text(Constants.Texts.General.okayText)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            
                        }
                        .buttonStyle(.borderless)
                        
                        
                        
                    }
                    .padding(10)
                    .background(Color(white: 1, opacity: 0.9))
                    .cornerRadius(30)
                    
                }
                
                // slider to change position of the sun
                
                Slider(value: $sunPositionX, in: 0...(UIScreen.main.bounds.width - 150) ,
                       onEditingChanged:
                        { editing in
                   
                            // change the blinds depending on the position of the sun/slider
                            withAnimation(.easeInOut(duration: 1.0))
                            {
                                if sunPositionX >= 490
                                {
                                    blindsImageName = UIImage(named:Constants.Images.BlindsView.blindsClose)!
                                    
                                    
                                }
                                else
                                {
                                    blindsImageName = UIImage(named: Constants.Images.BlindsView.blindsOpen)!
                                    
                                }
                    }
                    
                })
                .tint(.yellow)
                .padding(10)
                
                if !showExplanation // if not showing the explanation, show buttons of how can al do this and X to close
                {
                    
                    HStack
                    {
                        Spacer()
                        Button(action: {showInfoEvent.send()})
                        {
                            Text(Constants.Texts.General.howCanAlDoThis)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            
                            
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Spacer()
                        
                        Button(action: {changeSceneEvent.send(.HouseView)})
                        {
                            Text("X")
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                
                            
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Spacer()
                    }
                    
                }
                
            }
            .padding(30)
            .background(
                Image(uiImage:blindsImageName) // the background changes to change the blind
                    .resizable()
                    .scaledToFill()
                    .transition(.opacity)
                    .ignoresSafeArea())
            .onReceive(blindsExplanationEvent)
            {
                showExplanation.toggle()
            }
            .onReceive(showInfoEvent)
            {
                showInfo.toggle()
            }
            
            
            if showInfo // if shows info about the view
            {
                AiInfoView(infoType: .BlindsInfo)
            }
            
        }
        
    }
}

struct BlindsView_Previews: PreviewProvider
{
    static var previews: some View
    {
        BlindsView()
    }
}
