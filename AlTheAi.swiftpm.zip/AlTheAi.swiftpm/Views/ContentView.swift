import SwiftUI
import UIKit

// view to manage all of the views

public struct ContentView: View 
{
    @State var activeView: ActiveView = .HouseView
    @State var firstTime = true
    
    @State var showMenu: Bool = false
    
    public var body: some View
    {
        
        ZStack
        {
            
            // active view
            switch activeView
            {
                
                case .HouseView:
                    VStack
                    {
                        
                        HouseView()
                        
                        if firstTime // if it is the first time the user enters the app
                        {
                            
                                HStack
                                {
                                    Spacer()
                                    
                                    VStack // 360 and arrow text
                                    {
                                        
                                        Text("360° View")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                          
                                        Image(systemName: "arrow.turn.down.right")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30)
                                                                                   
                                        Spacer()
                                    }
                                    .padding(20)
                                    
                                }
                                .padding(70)
                            
                            AlIntroView() // show introduction view
                            
                        }
                }
                    
                case .AlIntroView:
                    AlIntroView()
                    
                case .FridgeView:
                    FridgeView()
                    
                case .TvView:
                    TvView()
                    
                case .ComputerView:
                    ComputerView()
                        .layoutPriority(0)
                    
                case .BlindsView:
                    BlindsView()
                
                case .PhoneView:
                    PhoneView()
                
            }
            
            if showMenu
            {
                MenuView()
                
            }
            else
            {
                // menu button / view
                VStack(alignment: .trailing)
                {
                    
                    HStack(alignment: .top)
                    {
                        
                        Spacer()
                        
                        
                        Button (action: {showMenuEvent.send()})
                        {
                            Image(systemName: "line.3.horizontal.circle")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.gray)
                                .padding(30)
                            
                        }
                        .layoutPriority(1)
                        
                        
                    }
                    
                    Spacer()
                }
            }
        }
        // when changing views hide menu and change the view
        .onReceive(changeSceneEvent){ newActiveView in
            showMenu = false
            activeView = newActiveView
        }
        .onReceive(dismissIntroEvent)
        {
            firstTime = false
        }
        .onReceive(showMenuEvent)
        {
            showMenu.toggle()
        }
        .statusBar(hidden: true)
        .previewInterfaceOrientation(.landscapeRight)
        
    }
    
}
