import SwiftUI

struct RecipeView: View
{
   
    @State var text: String = "" // the current text that is being typed
    
    let finalText: String = Constants.Texts.FridgeView.recipeText // the final text that will be typed
    
    @State var textFinishedTyping: Bool = false
           

    var body: some View {
        
        VStack
        {
            
            
            HStack()
            {
                
                // image of al and text of the recipe that will enter with typewriter effect
                
                Image(Constants.Images.alImage)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 70, height: 70)
                    .padding(.trailing, 10)
                
                ScrollView
                {
                    Text(text) // the text changes with the typewriter effect
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                        .lineSpacing(15)
                }
                .padding(.bottom, 10)
                
            }
            .onAppear() // activate typewriter effect when the view starts
            {
                typewriter()
            }
            
            // if the text finished typing
            if text == finalText
            {
                HStack(alignment: .center)
                {
                
                    // button thank you
                    Button( Constants.Texts.General.thankYouText,
                            action: { changeSceneEvent.send(.HouseView) })
                    .buttonStyle(.borderless)
                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                    .padding(.trailing, 30)

                    // button how can AL do this?
                    Button(Constants.Texts.General.howCanAlDoThis ,action: { showInfoEvent.send() } )
                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                    .buttonStyle(.borderless)
                    .padding(.leading, 30)
                    
                }

            }
            
        }
        .padding(30) // inside padding
        .background(Color(white: 1, opacity: 0.9))
        .cornerRadius(30)
        .padding(30) // outside padding
        
        
        
    }
        
    // function to make the typewriter effect
    func typewriter(at position: Int = 0)
    {
            
        if position == 0
        {
                text = ""
        }
        if position < finalText.count
        {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05)
                {
                    text.append(finalText[position])
                    typewriter(at: position + 1)
                }
            
        }
        
    }

  
}

struct RecipeView_Previews: PreviewProvider
{
    static var previews: some View
    {
        RecipeView()
    }

}


extension String
{
    subscript(offset: Int) -> Character {
        self[index(startIndex, offsetBy: offset)]
    }
}
