import SwiftUI
import UIKit
import SceneKit

public struct FridgeViewControllerRepresentable: UIViewControllerRepresentable
{

    public func makeUIViewController(context: Context) -> FridgeViewController
    {
        
        return FridgeViewController()
        
    }
    
    public func updateUIViewController(_ uiViewController: FridgeViewController, context: Context)
    {
        
    }
    

}

public class FridgeViewController: UIViewController
{
    var scene: SCNScene!
    
    var sceneView: SCNView = SCNView()
   
    var objects: [ObjectSet] = []
    
    public override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setup()
        
    }
    
    // function to setup the 3d scene
    func setup()
    {
        sceneView.frame = CGRect(origin: .zero, size: view.frame.size)
       
        scene = SCNScene(named: Constants.Scenes.fridgeScene)
        
        sceneView.scene = scene
        sceneView.autoenablesDefaultLighting = true
        sceneView.isUserInteractionEnabled = true
        sceneView.allowsCameraControl = false
       
        view.addSubview(sceneView)
    }

}
    
public struct FridgeView: View
    
{
    @State var showRecipe: Bool = false
    
    @State var showShoppingList: Bool = false
    
    @State var showInfoAiRecipe: Bool = false
    
    public var body: some View
    {
        
        
        ZStack
        {
            
            
            HStack
            {
                FridgeViewControllerRepresentable()
                    .ignoresSafeArea()
                
                
                if !showRecipe // if is not showing the recipe, show button to show the recipe
                {
                    
                    VStack()
                    {
                        
                        Text(Constants.Texts.FridgeView.whatDoYouNeedHelpWithText)
                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                            .padding(.bottom, 30)
                            .lineSpacing(15)
                        
                        
                        Button(Constants.Texts.FridgeView.iDontKnowCookText, action: {fridgeShowRecipeEvent.send()} )
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                        .buttonStyle( .borderedProminent)
                        .lineSpacing(15)
                    }
                    .padding(.trailing, 50)
                }
                
                
            }
            .onReceive(fridgeShowRecipeEvent)
            {
                showRecipe.toggle()
                
            }
            .onReceive(showInfoEvent)
            {
                showInfoAiRecipe.toggle()
                showRecipe = false
            }
            
            
            if showRecipe && !showInfoAiRecipe // if show the recipe: call View to show the recipe
            {
                Spacer()
                
                RecipeView()
                
            }
            if showInfoAiRecipe && !showRecipe // if show the Ai info, call View to show the info
            {
                
                AiInfoView(infoType: .RecipeInfo)
                    
                
            }
            
            
        }
        
        
    }
    
}
