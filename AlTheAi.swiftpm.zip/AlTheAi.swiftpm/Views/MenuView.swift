import SwiftUI

// view of the menu that is always in the top of the app

struct MenuView: View {
  
    @State var showGoalOfApp: Bool = false
    @State var showCredits: Bool = false
    
    var body: some View {
        
        ZStack
        {
            VStack(alignment: .center)
            {
                
                Spacer()
                
                Text("Menu")
                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontMiddle))
                    .foregroundColor(.gray)
                    .padding(.bottom, 10)
                
                Spacer()
                
                Button("Goal of the app", action: {menuGoalOfTheAppEvent.send()})
                    .buttonStyle(.borderless)
                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontBig))
                
                
                Spacer()
                
                Button("Credits", action: {menuCreditsEvent.send()})
                    .buttonStyle(.borderless)
                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontBig))
                
                Spacer()
                
                HStack(alignment: .center)
                {
                    // back home (house view) button
                    Button(action: {changeSceneEvent.send(.HouseView)})
                    {
                        
                        Image(systemName: "house.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .accessibilityLabel(Constants.AccessibilityLabelsText.buttonBackHome)
                    }
                    .padding(.trailing, 30)
                    
                    // quit button
                    Button("X", action: {showMenuEvent.send()})
                        .accessibilityLabel(Constants.AccessibilityLabelsText.buttonQuitLabel)
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontBig))
                        .padding(.leading, 30)
                    
                }
                .padding(30)
                
                
            }
            
            if showGoalOfApp
            {
                AiInfoView(infoType: .GoalOfApp)
                
            }
            else if showCredits
            {
                AiInfoView(infoType: .Credits)
            }
            
            
        }
        .padding(150) // inside padding
        .background(Color(white: 1, opacity: 0.8))
        .cornerRadius(30)
        .padding(.top, 30) // outside padding
        .padding(.bottom, 30) // outside padding
        .onReceive(menuCreditsEvent)
        {
            showCredits.toggle()
        }
        .onReceive(menuGoalOfTheAppEvent)
        {
            showGoalOfApp.toggle()
        }
        .onReceive(showInfoEvent)
        {
            showGoalOfApp = false
            showCredits = false
        }
        
    }
}

struct MenuView_Previews: PreviewProvider
{
    static var previews: some View
    {
        MenuView()
    }
}
