
import SwiftUI

// view that will be shown in the first time the user enters the app

struct AlIntroView: View {
   
    
    var body: some View {
        
    
            VStack
            {
                HStack // image of Al and introduction text
                {
                    
                    Image(Constants.Images.alImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .padding(.trailing, 10)
                   
                    
                        Text(Constants.Texts.AlIntro.introText)
                            .lineSpacing(15)
                            .lineLimit(.max)
                            .font(Font.custom(Constants.Fonts.robotFont, size: 15))
                            .fixedSize(horizontal: false, vertical: true)
                    
                    
                }
                .padding(.bottom, 15)
                
                
                Button(action: {dismissIntroEvent.send() })
                {
                    Text(Constants.Texts.AlIntro.buttonIntro)
                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                    
                }
            }
            .padding(30)
            .background(Color(.white))
            .opacity(0.95)
            .cornerRadius(20)
           
    }
}

struct AlIntroView_Previews: PreviewProvider {
    
    static var previews: some View {
        AlIntroView()
            
    }
}
