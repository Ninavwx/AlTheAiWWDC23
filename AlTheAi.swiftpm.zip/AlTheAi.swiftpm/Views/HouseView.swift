import SwiftUI
import UIKit
import SceneKit

public struct HouseViewControllerRepresentable: UIViewControllerRepresentable
{

    public func makeUIViewController(context: Context) -> HouseViewController
    {
        
        return HouseViewController()
        
    }
    
    public func updateUIViewController(_ uiViewController: HouseViewController, context: Context)
    {
        
    }
    

}

public class HouseViewController: UIViewController
{
    var scene: SCNScene!
    var sceneView: SCNView = SCNView()
   
    var objects: [ObjectSet] = []
    
    public override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setup()
        
        // new
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTapView(_:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
        
       
    }
    
    // function to setup the 3d scene
    func setup()
    {
        sceneView.frame = CGRect(origin: .zero, size: view.frame.size)
       
        scene = SCNScene(named: Constants.Scenes.houseScene)
        
        sceneView.scene = scene
        sceneView.autoenablesDefaultLighting = true
        sceneView.isUserInteractionEnabled = true
        sceneView.allowsCameraControl = true
       
        view.addSubview(sceneView)
    }
    
    @objc func didTapView(_ sender: UITapGestureRecognizer)
    {
        
        let location: CGPoint = sender.location(in: sceneView)
        
        
       let hits = self.sceneView.hitTest(location, options: nil)
        
        print(hits)
       
        for hit in hits
        {
            
            let tappedNode = hit.node
            
            // call function to handle the tap
            handleTap(objId: tappedNode.name!)
            
        }
       
    }
    
    
    /*
      Function to check what object was tapped and act accordingly
      input: the tapped object id
     */
    func handleTap (objId: String)
    {
        
        // test the object id and act accordingly
        switch objId
        {
            case Constants.ObjIds.HouseView.fridgeId:
                    changeSceneEvent.send(.FridgeView)
            
            case Constants.ObjIds.HouseView.blindsId:
                changeSceneEvent.send(.BlindsView)
            
            case Constants.ObjIds.HouseView.iphoneId:
            changeSceneEvent.send(.PhoneView)
                
            case Constants.ObjIds.HouseView.computerId:
            changeSceneEvent.send(.ComputerView)
            
            case Constants.ObjIds.HouseView.tvId:
                changeSceneEvent.send(.TvView)
                
            default: break
            
            
        }
            
        
    }
    
    
}
    
public struct HouseView: View
{
        
    
        public var body: some View
        {
            
            VStack
            {
                
                HouseViewControllerRepresentable()
                
              
            }
            .ignoresSafeArea()
            
        }

    
        
}


