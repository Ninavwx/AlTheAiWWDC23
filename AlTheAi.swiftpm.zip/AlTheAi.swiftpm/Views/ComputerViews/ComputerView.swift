
import SwiftUI

struct ComputerView: View {
   
    @State var isUserWritingEmail: Bool = false
    
    @State var isAlWritingEmail: Bool = false
    
    @State var nameReceiver: String = ""
     
    @State var nameEvent: String = ""
    
    @State var timeEvent: String = ""
    
    @State var typeEmail: TypeEmail = .Formal
    
    @State var showInfoComputer: Bool = false
    
    
    var body: some View {
        
        ZStack
        {
            HStack
            {
                
                Spacer()
                
                VStack (alignment: .center)
                {
                    Spacer()
                    
                    if !isUserWritingEmail && !isAlWritingEmail // if  is in the start computer view, show the button to write
                    {
                        VStack(alignment: .center)
                            {
                                Button(action: {userWritingEmailEvent.send()})
                                {
                                    VStack
                                    {
                                        
                                        Image(systemName: "envelope")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 100, height: 100)
                                            .padding(.bottom, 5)
                                        
                                        Text(Constants.Texts.ComputerView.sendEmailToFriendText)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                    }
                                    
                                }
                                .padding(10)
                                .foregroundColor(.gray)
                                .background(Color(white: 1, opacity: 0.9))
                                .cornerRadius(30)
                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontBig))
                            }
                            
                    }
                    else if isUserWritingEmail && !isAlWritingEmail // ask al to write email (give the details)
                    {
                        ZStack
                        {
                            VStack(alignment: .center)
                            {
                                
                                Spacer() // makes it full screen
                                
                                HStack
                                {
                                    Spacer()
                                    Image(Constants.Images.alImage)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50, height: 50)
                                        .padding(.trailing, 10)
                                    
                                    Text("* Fill in with the details and I will write an email for you")
                                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                    
                                    Spacer()
                                }
                                .padding(20)
                                
                                VStack(alignment: .leading)
                                {
                                    HStack
                                    {
                                        
                                        Spacer() // makes full screen
                                        
                                        Text(Constants.Texts.ComputerView.pleaseWriteEmailToText)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        
                                        // text to enter age
                                        TextField("name of the friend", text: $nameReceiver)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .background(Color(.gray).frame(height: 2).padding(.top, 15).cornerRadius(10))
                                        
                                        Spacer() // makes full screen
                                    }
                                    .padding(.bottom, 20)
                                    
                                    HStack
                                    {
                                        Spacer()
                                        
                                        Text(Constants.Texts.ComputerView.invitingHimTo)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                         
                                        // text to enter age
                                        TextField( "event", text: $nameEvent)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .background(Color(.gray).frame(height: 2).padding(.top, 15).cornerRadius(10))
                                        
                                        Text(" at ")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        
                                        // text to enter age
                                        TextField("time", text: $timeEvent)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .background(Color(.gray).frame(height: 2).padding(.top, 15).cornerRadius(10))
                                        Spacer()
                                        
                                    }
                                    .padding(.bottom, 20)
                                    
                                    HStack
                                    {
                                        Text("It is ")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        
                                        
                                        Picker("Formal email", selection: $typeEmail)
                                        {
                                            Text("a formal")
                                                .tag(TypeEmail.Formal)
                                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            
                                            Text("an informal")
                                                .tag(TypeEmail.Informal)
                                                .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            
                                        }
                                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        .scaledToFit()
                                        .pickerStyle(.segmented)
                                        .padding(.leading, 10)
                                        .padding(.trailing, 10)
                                        
                                        Text(" email.")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                        
                                        
                                    }
                            }
                                Spacer()
                                
                                Button(action: {alWritingEmailEvent.send()}) // add action to send the email
                                {
                                    Text("Write the email")
                                        .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                }
                                .buttonStyle(.borderedProminent)
                                
                                Spacer() // makes it full screen
                                
                            }
                            .padding(30)
                            .background(Color(white: 1, opacity: 0.95))
                            .cornerRadius(30)
                            
                            
                        }
                    }
                    else if isAlWritingEmail && !isUserWritingEmail // the resulting email that Al wrote
                    {
                        
                        HStack
                        {
                            Spacer()// makes it full screen
                            
                            VStack(alignment: .leading)
                            {
                                
                                Spacer() // makes it full screen
                                
                                Text("from: myEmail@email.com\n\nto: \(nameReceiver)@email.com")
                                    .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                    .padding(.bottom, 20)
                                
                                // writes the texts according to the type of the email
                                switch typeEmail
                                {
                                    case .Formal:
                                        Text("Dear \(nameReceiver),\n\nI would like to invite you to \(nameEvent) that will happen at \(timeEvent).\n\nThank you for your consideration, hope to see you there.\n\nBest regards")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .padding(.bottom, 20)
                                    
                                    case .Informal:
                                        Text("Hey \(nameReceiver),\n\nHow's it going?\n\nWhat do you say about coming to \(nameEvent) at \(timeEvent)?\n\nAre you in?\n\nPlease let me know asap!\n\nTake care!")
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                            .padding(.bottom, 50)
                                }
                                
                                HStack
                                {
                                    
                                    Button(action: {changeSceneEvent.send(.HouseView)}) // add action to send/quit
                                    {
                                        Image(systemName: "paperplane")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30)
                                            .foregroundColor(.blue)
                                    }
                                    .padding(.trailing, 30)
                                    
                                    Button( action: {showInfoEvent.send()})
                                    {
                                        Text(Constants.Texts.General.howCanAlDoThis)
                                            .font(Font.custom(Constants.Fonts.robotFont, size: Constants.Fonts.robotFontSmall))
                                    }
                                    .buttonStyle( .borderless)
                                }
                                Spacer() // makes it full screen
                                
                
                            }
                            
                            Spacer() // makes it full screen
                        }
                        .padding(30)
                        .background(Color(white: 1, opacity: 0.95))
                        .cornerRadius(30)
                        
                    }
                    
                    Spacer()
                }
                
                Spacer()
                
            }
           
            Spacer()
            
        }
        .background(Image(Constants.Images.ComputerView.computerBackground).resizable().ignoresSafeArea())
        .onReceive(userWritingEmailEvent)
        {
            isUserWritingEmail.toggle()
        }
        .onReceive(alWritingEmailEvent)
        {
            isUserWritingEmail = false
            isAlWritingEmail.toggle()
        }
        .onReceive(showInfoEvent)
        {
            showInfoComputer.toggle()
        }
    
        if showInfoComputer
        {
            
            AiInfoView(infoType: .EmailInfo)
            
        }
    }
    

    
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        ComputerView()
    }
}

// enum for the email to be formal or informal
public enum TypeEmail
{
    
    case Formal
    case Informal
    
}


